7. Opera sistemas empresariales de gestión de información realizando tareas de importación, integración, aseguramiento y extracción de la información.

Criterios de evaluación:

a) Se han identificado los principales sistemas de gestión empresarial.

b) Se han reconocido las ventajas de los sistemas de gestión de información empresariales.

c) Se han evaluado las características de las principales aplicaciones de gestión empresarial.

d) Se han instalado aplicaciones de gestión de la información empresarial.

e) Se han configurado y administrado las aplicaciones.

f) Se han establecido y verificado mecanismos de acceso seguro a la información.

g) Se han generado informes.

h) Se han realizado procedimientos de extracción de información para su tratamiento e incorporación a diversos sistemas.

i) Se han elaborado documentos relativos a la explotación de la aplicación.


