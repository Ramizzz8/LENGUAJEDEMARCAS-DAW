3. Accede y manipula documentos web utilizando lenguajes de script de cliente.

Criterios de evaluación:

a) Se han identificado y clasificado los lenguajes de script de cliente relacionados con la web y sus diferentes versiones y estándares.

b) Se ha identificado la sintaxis básica de los lenguajes de script de cliente.

c) Se han utilizado métodos para la selección y acceso de los diferentes elementos de un documento web.

d) Se han creado y modificado elementos de documentos web.

e) Se han eliminado elementos de documentos web.

f) Se han realizado modificaciones sobre los estilos de un documento web.
