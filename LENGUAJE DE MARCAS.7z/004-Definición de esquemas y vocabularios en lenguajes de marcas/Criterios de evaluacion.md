4. Establece mecanismos de validación de documentos para el intercambio de información utilizando métodos para definir su sintaxis y estructura.

Criterios de evaluación:

a) Se ha establecido la necesidad de describir la información transmitida en los documentos y sus reglas.

b) Se han identificado las tecnologías relacionadas con la definición de documentos.

c) Se ha analizado la estructura y sintaxis específica utilizada en la descripción.

d) Se han creado descripciones de documentos.

e) Se han utilizado descripciones en la elaboración y validación de documentos.

f) Se han asociado las descripciones con los documentos.

g) Se han utilizado herramientas específicas.
