5. Realiza conversiones sobre documentos para el intercambio de información utilizando técnicas, lenguajes y herramientas de procesamiento.

Criterios de evaluación:

a) Se ha identificado la necesidad de la conversión de documentos para el intercambio de la información.

b) Se han establecido ámbitos de aplicación.

c) Se han analizado las tecnologías implicadas y su modo de funcionamiento.

d) Se ha descrito la sintaxis específica utilizada en la conversión y adaptación de documentos para el intercambio de información.

e) Se han creado especificaciones de conversión.

f) Se han identificado y caracterizado herramientas específicas relacionadas con la conversión de documentos para el intercambio de información.

g) Se han realizado conversiones sobre documentos para el intercambio de información.


