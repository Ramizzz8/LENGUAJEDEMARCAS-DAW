2. Utiliza lenguajes de marcas para la transmisión y presentación de información a través de la web analizando la estructura de los documentos e identificando sus elementos.

Criterios de evaluación:

a) Se han identificado y clasificado los lenguajes de marcas relacionados con la web y sus diferentes versiones y estándares.

b) Se ha analizado la estructura de un documento HTML e identificado las secciones que lo componen.

c) Se ha reconocido la funcionalidad de las principales etiquetas y los atributos del lenguaje HTML.

d) Se han establecido las semejanzas y diferencias entre las diferentes versiones de HTML.

e) Se han utilizado herramientas en la creación de documentos web.

f) Se han identificado las ventajas que aporta la utilización de hojas de estilo.

g) Se han aplicado hojas de estilo.

h) Se han validado documentos HTML y CSS.

i) Se han identificado las tecnologías en que se basa la sindicación de contenidos.

j) Se han reconocido los ámbitos de aplicación de la sindicación de contenidos.
