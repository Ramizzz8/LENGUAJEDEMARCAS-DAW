1. Reconoce las características de lenguajes de marcas analizando e interpretando fragmentos de código.

Criterios de evaluación:

a) Se han identificado las características generales de los lenguajes de marcas.

b) Se han reconocido las ventajas que proporcionan en el tratamiento de la información.

c) Se han clasificado los lenguajes de marcas e identificado los más relevantes.

d) Se han diferenciado sus ámbitos de aplicación.

e) Se han reconocido la necesidad y los ámbitos específicos de aplicación de un lenguaje de marcas de propósito general.

f) Se han analizado las características propias de diferentes lenguajes de marcas.

g) Se ha identificado la estructura de un documento y sus reglas sintácticas.

h) Se ha contrastado la necesidad de crear documentos bien formados y la influencia en su procesamiento.

i) Se han identificado las ventajas que aportan los espacios de nombres.
