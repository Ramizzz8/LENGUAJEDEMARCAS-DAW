Una cosa muy importante que nos enseña esta asignatura es la separación de estructura, presentación y datos

HTML = Estructura
CSS = Presentación, estilo, apariencia
XML = Datos
Javascript = Comportamiento
